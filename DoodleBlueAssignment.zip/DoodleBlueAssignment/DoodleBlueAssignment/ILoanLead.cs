﻿using DoodleBlueAssignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoodleBlueAssignment
{
    public interface ILoanLead
    {
        Task<int> ContactDetailInsert(ContactDetailModel item);
        Task<int> LeadInformationInsert(LeadInformationModel item);
        Task<int> CommunicationLogsInsert(CommunicationLogsModel item);
    }
}
