﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using DoodleBlueAssignment.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoodleBlueAssignment.Controllers
{
    public class LoanLeadController : Controller
    {
        readonly IHostingEnvironment _hostingEnvironment;
        readonly IHttpContextAccessor _httpContextAccessor;
        public LoanLead _loanlead;

        public LoanLeadController(IHostingEnvironment hostingEnvironment, IHttpContextAccessor httpContextAccessor)
        {
            this._hostingEnvironment = hostingEnvironment;
            this._httpContextAccessor = httpContextAccessor;
            _loanlead = new LoanLead(httpContextAccessor);
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult ContactDetail()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ContactDetail(ContactDetailModel item)
        {
            List<string> MessageList = new List<string>();
            if (!ModelState.IsValid)
            {
                MessageList.Add("All fields are required");
            }
            else
            {
                string emailRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
     @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
        @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
                Regex re = new Regex(emailRegex);
                if (!string.IsNullOrEmpty(item.EmailAddress) && !re.IsMatch(item.EmailAddress))
                {
                    MessageList.Add("Email Address is not valid");
                }
                string phoneRegex = @"^([0-9]{10})$";
                Regex phonere = new Regex(phoneRegex);
                if (!string.IsNullOrEmpty(item.ContactNumbers) && !phonere.IsMatch(item.ContactNumbers))
                {
                    MessageList.Add("Contact Number is not valid");
                }
                string dateRegex = "^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$";
                Regex datere = new Regex(dateRegex);
                if (!string.IsNullOrEmpty(item.DateofBirth) && !datere.IsMatch(item.DateofBirth.ToString()))
                {
                    MessageList.Add("Date is not valid");
                }
                else
                {
                    int ContactDetailID = await _loanlead.ContactDetailInsert(item);
                    MessageList.Add("Inserted successfully");
                    return RedirectToAction("LeadInformation", new { ContactDetailID = ContactDetailID });
                }
            }
            TempData["Message"] = MessageList;
            return View(item);
        }

        [HttpGet]
        public IActionResult LeadInformation(int ContactDetailID)
        {
            LeadInformationModel item = new LeadInformationModel();
            item.ContactDetailID = ContactDetailID;
            return View(item);
        }

        [HttpPost]
        public async Task<IActionResult> LeadInformation(LeadInformationModel item)
        {
            List<string> MessageList = new List<string>();
            if (!ModelState.IsValid)
            {
                MessageList.Add("All fields are required");
            }
            string dateRegex = "^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$";
            Regex datere = new Regex(dateRegex);
            if (!string.IsNullOrEmpty(item.CommunicationDate) && !datere.IsMatch(item.CommunicationDate.ToString()))
            {
                MessageList.Add("Date is not valid");
            }
            else
            {
                var response = await _loanlead.LeadInformationInsert(item);
            }
            return View();
        }
    }
}