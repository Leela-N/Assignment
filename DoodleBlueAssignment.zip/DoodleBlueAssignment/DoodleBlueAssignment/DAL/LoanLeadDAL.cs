﻿using DoodleBlueAssignment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;
using Microsoft.AspNetCore.Http;

namespace DoodleBlueAssignment.DAL
{
    public class LoanLeadDAL
    {

        readonly IHttpContextAccessor _httpContextAccessor;
        public LoanLeadDAL(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public static string sqlDataSource = "Data Source= DESKTOP-ES9UV20\\SQLEXPRESS; Database= Assignment; Integrated Security=True;";

        public async Task<int> ContactDetailInsert(ContactDetailModel item)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlDataSource))
                {
                    con.Open();
                    var param =
                        new
                        {
                            ContactType = item.ContactType,
                            ContactName = item.ContactName,
                            DateofBirth = Convert.ToDateTime(item.DateofBirth),
                            Gender = item.Gender,
                            EmailAddress = item.EmailAddress,
                            ContactNumbers = item.ContactNumbers
                        };
                    var result = await con.ExecuteScalarAsync<int>("ContactDetailInsert", param, commandType: CommandType.StoredProcedure);
                    return result;
                }
            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        public async Task<int> LeadInformationInsert(LeadInformationModel item)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlDataSource))
                {
                    con.Open();
                    var param =
                        new
                        {
                            LoanAmount = item.LoanAmount,
                            LeadSource = item.LeadSource,
                            CommunicationMode = item.CommunicationMode,
                            CurrentStatus = item.CurrentStatus,
                            ContactDetailID = item.ContactDetailID,
                            CommunicationDate = item.CommunicationDate
                        };
                    var result = await con.ExecuteScalarAsync<int>("LeadInformationInsert", param, commandType: CommandType.StoredProcedure);
                    return result;
                }
            }
            catch (Exception ex)
            {
                return -1;
            }
        }

    }
}
