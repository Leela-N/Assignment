﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoodleBlueAssignment.Models
{
    public class LoanLeadModel
    {


    }

    public class LeadInformationModel
    {
        public int LeadID { get; set; }
        public string LoanAmount { get; set; }
        public string LeadSource { get; set; }
        public string CommunicationMode { get; set; }
        public string CurrentStatus { get; set; }
        public int ContactDetailID { get; set; }
        public string CommunicationDate { get; set; }

    }

    public class ContactDetailModel
    {
        public string ContactType { get; set; }
        public string ContactName { get; set; }
        public string DateofBirth { get; set; }
        public string Gender { get; set; }
        public string EmailAddress { get; set; }
        public string ContactNumbers { get; set; }
    }

    public class CommunicationLogsModel
    {
        public long LeadId { get; set; }
        public DateTime CommunicationDate { get; set; }
        public string CommunicationMode { get; set; }
        public string Status { get; set; }
    }
}
