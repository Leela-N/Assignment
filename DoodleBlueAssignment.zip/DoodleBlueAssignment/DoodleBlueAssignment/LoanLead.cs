﻿using DoodleBlueAssignment.DAL;
using DoodleBlueAssignment.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoodleBlueAssignment
{
    public class LoanLead
    {

        private LoanLeadDAL _loanleaddal;
        readonly IHttpContextAccessor _httpContextAccessor;
        public LoanLead(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _loanleaddal = new LoanLeadDAL(_httpContextAccessor);
        }

        public async Task<int> ContactDetailInsert(ContactDetailModel item)
        {
            try
            {
                var response = await _loanleaddal.ContactDetailInsert(item);
                return response;
            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        public async Task<int> LeadInformationInsert(LeadInformationModel item)
        {
            try
            {
                var response = await _loanleaddal.LeadInformationInsert(item);
                return response;
            }
            catch (Exception ex)
            {
                return -1;
            }
        }
    }
}
